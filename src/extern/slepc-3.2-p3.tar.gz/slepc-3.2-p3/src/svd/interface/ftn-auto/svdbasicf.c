#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* svdbasic.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcsvd.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define svdprintsolution_ SVDPRINTSOLUTION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define svdprintsolution_ svdprintsolution
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define svdreset_ SVDRESET
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define svdreset_ svdreset
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define svdregisterdestroy_ SVDREGISTERDESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define svdregisterdestroy_ svdregisterdestroy
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define svdsetip_ SVDSETIP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define svdsetip_ svdsetip
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  svdprintsolution_(SVD *svd,PetscViewer viewer, int *__ierr ){
*__ierr = SVDPrintSolution(*svd,
	(PetscViewer)PetscToPointer((viewer) ));
}
void PETSC_STDCALL  svdreset_(SVD *svd, int *__ierr ){
*__ierr = SVDReset(*svd);
}
void PETSC_STDCALL  svdregisterdestroy_(int *__ierr ){
*__ierr = SVDRegisterDestroy();
}
void PETSC_STDCALL  svdsetip_(SVD *svd,IP *ip, int *__ierr ){
*__ierr = SVDSetIP(*svd,*ip);
}
#if defined(__cplusplus)
}
#endif
