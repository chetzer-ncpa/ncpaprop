#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* gd.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepceps.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdsetkrylovstart_ EPSGDSETKRYLOVSTART
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdsetkrylovstart_ epsgdsetkrylovstart
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdgetkrylovstart_ EPSGDGETKRYLOVSTART
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdgetkrylovstart_ epsgdgetkrylovstart
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdsetblocksize_ EPSGDSETBLOCKSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdsetblocksize_ epsgdsetblocksize
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdgetblocksize_ EPSGDGETBLOCKSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdgetblocksize_ epsgdgetblocksize
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdgetrestart_ EPSGDGETRESTART
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdgetrestart_ epsgdgetrestart
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdsetrestart_ EPSGDSETRESTART
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdsetrestart_ epsgdsetrestart
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdgetinitialsize_ EPSGDGETINITIALSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdgetinitialsize_ epsgdgetinitialsize
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdsetinitialsize_ EPSGDSETINITIALSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdsetinitialsize_ epsgdsetinitialsize
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdsetborth_ EPSGDSETBORTH
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdsetborth_ epsgdsetborth
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdgetborth_ EPSGDGETBORTH
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdgetborth_ epsgdgetborth
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdgetwindowsizes_ EPSGDGETWINDOWSIZES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdgetwindowsizes_ epsgdgetwindowsizes
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define epsgdsetwindowsizes_ EPSGDSETWINDOWSIZES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define epsgdsetwindowsizes_ epsgdsetwindowsizes
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  epsgdsetkrylovstart_(EPS *eps,PetscBool *krylovstart, int *__ierr ){
*__ierr = EPSGDSetKrylovStart(*eps,*krylovstart);
}
void PETSC_STDCALL  epsgdgetkrylovstart_(EPS *eps,PetscBool *krylovstart, int *__ierr ){
*__ierr = EPSGDGetKrylovStart(*eps,krylovstart);
}
void PETSC_STDCALL  epsgdsetblocksize_(EPS *eps,PetscInt *blocksize, int *__ierr ){
*__ierr = EPSGDSetBlockSize(*eps,*blocksize);
}
void PETSC_STDCALL  epsgdgetblocksize_(EPS *eps,PetscInt *blocksize, int *__ierr ){
*__ierr = EPSGDGetBlockSize(*eps,blocksize);
}
void PETSC_STDCALL  epsgdgetrestart_(EPS *eps,PetscInt *minv,PetscInt *plusk, int *__ierr ){
*__ierr = EPSGDGetRestart(*eps,minv,plusk);
}
void PETSC_STDCALL  epsgdsetrestart_(EPS *eps,PetscInt *minv,PetscInt *plusk, int *__ierr ){
*__ierr = EPSGDSetRestart(*eps,*minv,*plusk);
}
void PETSC_STDCALL  epsgdgetinitialsize_(EPS *eps,PetscInt *initialsize, int *__ierr ){
*__ierr = EPSGDGetInitialSize(*eps,initialsize);
}
void PETSC_STDCALL  epsgdsetinitialsize_(EPS *eps,PetscInt *initialsize, int *__ierr ){
*__ierr = EPSGDSetInitialSize(*eps,*initialsize);
}
void PETSC_STDCALL  epsgdsetborth_(EPS *eps,PetscBool *borth, int *__ierr ){
*__ierr = EPSGDSetBOrth(*eps,*borth);
}
void PETSC_STDCALL  epsgdgetborth_(EPS *eps,PetscBool *borth, int *__ierr ){
*__ierr = EPSGDGetBOrth(*eps,borth);
}
void PETSC_STDCALL  epsgdgetwindowsizes_(EPS *eps,PetscInt *pwindow,PetscInt *qwindow, int *__ierr ){
*__ierr = EPSGDGetWindowSizes(*eps,pwindow,qwindow);
}
void PETSC_STDCALL  epsgdsetwindowsizes_(EPS *eps,PetscInt *pwindow,PetscInt *qwindow, int *__ierr ){
*__ierr = EPSGDSetWindowSizes(*eps,*pwindow,*qwindow);
}
#if defined(__cplusplus)
}
#endif
