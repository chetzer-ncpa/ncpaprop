#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* qepsetup.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcqep.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsetup_ QEPSETUP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsetup_ qepsetup
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsetoperators_ QEPSETOPERATORS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsetoperators_ qepsetoperators
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepgetoperators_ QEPGETOPERATORS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepgetoperators_ qepgetoperators
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsetinitialspace_ QEPSETINITIALSPACE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsetinitialspace_ qepsetinitialspace
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsetinitialspaceleft_ QEPSETINITIALSPACELEFT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsetinitialspaceleft_ qepsetinitialspaceleft
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  qepsetup_(QEP *qep, int *__ierr ){
*__ierr = QEPSetUp(*qep);
}
void PETSC_STDCALL  qepsetoperators_(QEP *qep,Mat M,Mat C,Mat K, int *__ierr ){
*__ierr = QEPSetOperators(*qep,
	(Mat)PetscToPointer((M) ),
	(Mat)PetscToPointer((C) ),
	(Mat)PetscToPointer((K) ));
}
void PETSC_STDCALL  qepgetoperators_(QEP *qep,Mat *M,Mat *C,Mat *K, int *__ierr ){
*__ierr = QEPGetOperators(*qep,M,C,K);
}
void PETSC_STDCALL  qepsetinitialspace_(QEP *qep,PetscInt *n,Vec *is, int *__ierr ){
*__ierr = QEPSetInitialSpace(*qep,*n,is);
}
void PETSC_STDCALL  qepsetinitialspaceleft_(QEP *qep,PetscInt *n,Vec *is, int *__ierr ){
*__ierr = QEPSetInitialSpaceLeft(*qep,*n,is);
}
#if defined(__cplusplus)
}
#endif
