#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* qepopts.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcqep.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsetfromoptions_ QEPSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsetfromoptions_ qepsetfromoptions
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepgettolerances_ QEPGETTOLERANCES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepgettolerances_ qepgettolerances
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsettolerances_ QEPSETTOLERANCES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsettolerances_ qepsettolerances
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepgetdimensions_ QEPGETDIMENSIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepgetdimensions_ qepgetdimensions
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsetdimensions_ QEPSETDIMENSIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsetdimensions_ qepsetdimensions
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsetwhicheigenpairs_ QEPSETWHICHEIGENPAIRS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsetwhicheigenpairs_ qepsetwhicheigenpairs
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsetleftvectorswanted_ QEPSETLEFTVECTORSWANTED
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsetleftvectorswanted_ qepsetleftvectorswanted
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepgetscalefactor_ QEPGETSCALEFACTOR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepgetscalefactor_ qepgetscalefactor
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsetscalefactor_ QEPSETSCALEFACTOR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsetscalefactor_ qepsetscalefactor
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsetproblemtype_ QEPSETPROBLEMTYPE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsetproblemtype_ qepsetproblemtype
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepsettrackall_ QEPSETTRACKALL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepsettrackall_ qepsettrackall
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qepgettrackall_ QEPGETTRACKALL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qepgettrackall_ qepgettrackall
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  qepsetfromoptions_(QEP *qep, int *__ierr ){
*__ierr = QEPSetFromOptions(*qep);
}
void PETSC_STDCALL  qepgettolerances_(QEP *qep,PetscReal *tol,PetscInt *maxits, int *__ierr ){
*__ierr = QEPGetTolerances(*qep,tol,maxits);
}
void PETSC_STDCALL  qepsettolerances_(QEP *qep,PetscReal *tol,PetscInt *maxits, int *__ierr ){
*__ierr = QEPSetTolerances(*qep,*tol,*maxits);
}
void PETSC_STDCALL  qepgetdimensions_(QEP *qep,PetscInt *nev,PetscInt *ncv,PetscInt *mpd, int *__ierr ){
*__ierr = QEPGetDimensions(*qep,nev,ncv,mpd);
}
void PETSC_STDCALL  qepsetdimensions_(QEP *qep,PetscInt *nev,PetscInt *ncv,PetscInt *mpd, int *__ierr ){
*__ierr = QEPSetDimensions(*qep,*nev,*ncv,*mpd);
}
void PETSC_STDCALL  qepsetwhicheigenpairs_(QEP *qep,QEPWhich *which, int *__ierr ){
*__ierr = QEPSetWhichEigenpairs(*qep,*which);
}
void PETSC_STDCALL  qepsetleftvectorswanted_(QEP *qep,PetscBool *leftvecs, int *__ierr ){
*__ierr = QEPSetLeftVectorsWanted(*qep,*leftvecs);
}
void PETSC_STDCALL  qepgetscalefactor_(QEP *qep,PetscReal *alpha, int *__ierr ){
*__ierr = QEPGetScaleFactor(*qep,alpha);
}
void PETSC_STDCALL  qepsetscalefactor_(QEP *qep,PetscReal *alpha, int *__ierr ){
*__ierr = QEPSetScaleFactor(*qep,*alpha);
}
void PETSC_STDCALL  qepsetproblemtype_(QEP *qep,QEPProblemType *type, int *__ierr ){
*__ierr = QEPSetProblemType(*qep,*type);
}
void PETSC_STDCALL  qepsettrackall_(QEP *qep,PetscBool *trackall, int *__ierr ){
*__ierr = QEPSetTrackAll(*qep,*trackall);
}
void PETSC_STDCALL  qepgettrackall_(QEP *qep,PetscBool *trackall, int *__ierr ){
*__ierr = QEPGetTrackAll(*qep,trackall);
}
#if defined(__cplusplus)
}
#endif
