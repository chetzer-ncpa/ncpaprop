#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* linear.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcqep.h"
#include "slepceps.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qeplinearsetcompanionform_ QEPLINEARSETCOMPANIONFORM
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qeplinearsetcompanionform_ qeplinearsetcompanionform
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qeplineargetcompanionform_ QEPLINEARGETCOMPANIONFORM
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qeplineargetcompanionform_ qeplineargetcompanionform
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qeplinearsetexplicitmatrix_ QEPLINEARSETEXPLICITMATRIX
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qeplinearsetexplicitmatrix_ qeplinearsetexplicitmatrix
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qeplineargetexplicitmatrix_ QEPLINEARGETEXPLICITMATRIX
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qeplineargetexplicitmatrix_ qeplineargetexplicitmatrix
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qeplinearseteps_ QEPLINEARSETEPS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qeplinearseteps_ qeplinearseteps
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define qeplineargeteps_ QEPLINEARGETEPS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define qeplineargeteps_ qeplineargeteps
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  qeplinearsetcompanionform_(QEP *qep,PetscInt *cform, int *__ierr ){
*__ierr = QEPLinearSetCompanionForm(*qep,*cform);
}
void PETSC_STDCALL  qeplineargetcompanionform_(QEP *qep,PetscInt *cform, int *__ierr ){
*__ierr = QEPLinearGetCompanionForm(*qep,cform);
}
void PETSC_STDCALL  qeplinearsetexplicitmatrix_(QEP *qep,PetscBool *explicitmatrix, int *__ierr ){
*__ierr = QEPLinearSetExplicitMatrix(*qep,*explicitmatrix);
}
void PETSC_STDCALL  qeplineargetexplicitmatrix_(QEP *qep,PetscBool *explicitmatrix, int *__ierr ){
*__ierr = QEPLinearGetExplicitMatrix(*qep,explicitmatrix);
}
void PETSC_STDCALL  qeplinearseteps_(QEP *qep,EPS *eps, int *__ierr ){
*__ierr = QEPLinearSetEPS(*qep,*eps);
}
void PETSC_STDCALL  qeplineargeteps_(QEP *qep,EPS *eps, int *__ierr ){
*__ierr = QEPLinearGetEPS(*qep,
	(EPS* )PetscToPointer((eps) ));
}
#if defined(__cplusplus)
}
#endif
