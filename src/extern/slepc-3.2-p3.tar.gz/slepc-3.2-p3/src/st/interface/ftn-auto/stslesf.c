#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* stsles.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcst.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stsetksp_ STSETKSP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stsetksp_ stsetksp
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stgetksp_ STGETKSP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stgetksp_ stgetksp
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stgetoperationcounters_ STGETOPERATIONCOUNTERS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stgetoperationcounters_ stgetoperationcounters
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stresetoperationcounters_ STRESETOPERATIONCOUNTERS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stresetoperationcounters_ stresetoperationcounters
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stchecknullspace_ STCHECKNULLSPACE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stchecknullspace_ stchecknullspace
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  stsetksp_(ST *st,KSP ksp, int *__ierr ){
*__ierr = STSetKSP(*st,
	(KSP)PetscToPointer((ksp) ));
}
void PETSC_STDCALL  stgetksp_(ST *st,KSP* ksp, int *__ierr ){
*__ierr = STGetKSP(*st,ksp);
}
void PETSC_STDCALL  stgetoperationcounters_(ST *st,PetscInt* ops,PetscInt* lits, int *__ierr ){
*__ierr = STGetOperationCounters(*st,ops,lits);
}
void PETSC_STDCALL  stresetoperationcounters_(ST *st, int *__ierr ){
*__ierr = STResetOperationCounters(*st);
}
void PETSC_STDCALL  stchecknullspace_(ST *st,PetscInt *n, Vec V[], int *__ierr ){
*__ierr = STCheckNullSpace(*st,*n,V);
}
#if defined(__cplusplus)
}
#endif
