#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* stset.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcst.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stsetfromoptions_ STSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stsetfromoptions_ stsetfromoptions
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stsetmatstructure_ STSETMATSTRUCTURE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stsetmatstructure_ stsetmatstructure
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stgetmatstructure_ STGETMATSTRUCTURE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stgetmatstructure_ stgetmatstructure
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stsetmatmode_ STSETMATMODE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stsetmatmode_ stsetmatmode
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  stsetfromoptions_(ST *st, int *__ierr ){
*__ierr = STSetFromOptions(*st);
}
void PETSC_STDCALL  stsetmatstructure_(ST *st,MatStructure *str, int *__ierr ){
*__ierr = STSetMatStructure(*st,*str);
}
void PETSC_STDCALL  stgetmatstructure_(ST *st,MatStructure *str, int *__ierr ){
*__ierr = STGetMatStructure(*st,str);
}
void PETSC_STDCALL  stsetmatmode_(ST *st,STMatMode *mode, int *__ierr ){
*__ierr = STSetMatMode(*st,*mode);
}
#if defined(__cplusplus)
}
#endif
