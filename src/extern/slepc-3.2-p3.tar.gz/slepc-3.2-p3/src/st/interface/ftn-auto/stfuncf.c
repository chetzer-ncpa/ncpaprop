#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* stfunc.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcst.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define streset_ STRESET
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define streset_ streset
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stsetoperators_ STSETOPERATORS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stsetoperators_ stsetoperators
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stsetshift_ STSETSHIFT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stsetshift_ stsetshift
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stgetshift_ STGETSHIFT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stgetshift_ stgetshift
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stsetdefaultshift_ STSETDEFAULTSHIFT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stsetdefaultshift_ stsetdefaultshift
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stsetbalancematrix_ STSETBALANCEMATRIX
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stsetbalancematrix_ stsetbalancematrix
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stgetbalancematrix_ STGETBALANCEMATRIX
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stgetbalancematrix_ stgetbalancematrix
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define stregisterdestroy_ STREGISTERDESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define stregisterdestroy_ stregisterdestroy
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  streset_(ST *st, int *__ierr ){
*__ierr = STReset(*st);
}
void PETSC_STDCALL  stsetoperators_(ST *st,Mat A,Mat B, int *__ierr ){
*__ierr = STSetOperators(*st,
	(Mat)PetscToPointer((A) ),
	(Mat)PetscToPointer((B) ));
}
void PETSC_STDCALL  stsetshift_(ST *st,PetscScalar *shift, int *__ierr ){
*__ierr = STSetShift(*st,*shift);
}
void PETSC_STDCALL  stgetshift_(ST *st,PetscScalar* shift, int *__ierr ){
*__ierr = STGetShift(*st,shift);
}
void PETSC_STDCALL  stsetdefaultshift_(ST *st,PetscScalar *defaultshift, int *__ierr ){
*__ierr = STSetDefaultShift(*st,*defaultshift);
}
void PETSC_STDCALL  stsetbalancematrix_(ST *st,Vec D, int *__ierr ){
*__ierr = STSetBalanceMatrix(*st,
	(Vec)PetscToPointer((D) ));
}
void PETSC_STDCALL  stgetbalancematrix_(ST *st,Vec *D, int *__ierr ){
*__ierr = STGetBalanceMatrix(*st,D);
}
void PETSC_STDCALL  stregisterdestroy_(int *__ierr ){
*__ierr = STRegisterDestroy();
}
#if defined(__cplusplus)
}
#endif
