#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* iporthog.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcip.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define iporthogonalize_ IPORTHOGONALIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define iporthogonalize_ iporthogonalize
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ipqrdecomposition_ IPQRDECOMPOSITION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define ipqrdecomposition_ ipqrdecomposition
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ipbiorthogonalize_ IPBIORTHOGONALIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define ipbiorthogonalize_ ipbiorthogonalize
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  iporthogonalize_(IP *ip,PetscInt *nds,Vec *DS,PetscInt *n,PetscBool *which,Vec *V,Vec v,PetscScalar *H,PetscReal *norm,PetscBool *lindep, int *__ierr ){
*__ierr = IPOrthogonalize(*ip,*nds,DS,*n,which,V,
	(Vec)PetscToPointer((v) ),H,norm,lindep);
}
void PETSC_STDCALL  ipqrdecomposition_(IP *ip,Vec *V,PetscInt *m,PetscInt *n,PetscScalar *R,PetscInt *ldr, int *__ierr ){
*__ierr = IPQRDecomposition(*ip,V,*m,*n,R,*ldr);
}
void PETSC_STDCALL  ipbiorthogonalize_(IP *ip,PetscInt *n,Vec *V,Vec *W,Vec v,PetscScalar *H,PetscReal *norm, int *__ierr ){
*__ierr = IPBiOrthogonalize(*ip,*n,V,W,
	(Vec)PetscToPointer((v) ),H,norm);
}
#if defined(__cplusplus)
}
#endif
