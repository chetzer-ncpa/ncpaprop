#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* ipborthog.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcip.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ipborthogonalize_ IPBORTHOGONALIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define ipborthogonalize_ ipborthogonalize
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  ipborthogonalize_(IP *ip,PetscInt *nds,Vec *DS,Vec *BDS,PetscInt *n,PetscBool *which,Vec *V,Vec *BV,Vec v,Vec Bv,PetscScalar *H,PetscReal *norm,PetscBool *lindep, int *__ierr ){
*__ierr = IPBOrthogonalize(*ip,*nds,DS,BDS,*n,which,V,BV,
	(Vec)PetscToPointer((v) ),
	(Vec)PetscToPointer((Bv) ),H,norm,lindep);
}
#if defined(__cplusplus)
}
#endif
