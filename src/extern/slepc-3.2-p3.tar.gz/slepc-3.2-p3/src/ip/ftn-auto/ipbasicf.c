#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* ipbasic.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcip.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ipsetfromoptions_ IPSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define ipsetfromoptions_ ipsetfromoptions
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ipsetorthogonalization_ IPSETORTHOGONALIZATION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define ipsetorthogonalization_ ipsetorthogonalization
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ipgetoperationcounters_ IPGETOPERATIONCOUNTERS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define ipgetoperationcounters_ ipgetoperationcounters
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ipresetoperationcounters_ IPRESETOPERATIONCOUNTERS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define ipresetoperationcounters_ ipresetoperationcounters
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ipregisterdestroy_ IPREGISTERDESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define ipregisterdestroy_ ipregisterdestroy
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  ipsetfromoptions_(IP *ip, int *__ierr ){
*__ierr = IPSetFromOptions(*ip);
}
void PETSC_STDCALL  ipsetorthogonalization_(IP *ip,IPOrthogType *type,IPOrthogRefineType *refine,PetscReal *eta, int *__ierr ){
*__ierr = IPSetOrthogonalization(*ip,*type,*refine,*eta);
}
void PETSC_STDCALL  ipgetoperationcounters_(IP *ip,PetscInt *dots, int *__ierr ){
*__ierr = IPGetOperationCounters(*ip,dots);
}
void PETSC_STDCALL  ipresetoperationcounters_(IP *ip, int *__ierr ){
*__ierr = IPResetOperationCounters(*ip);
}
void PETSC_STDCALL  ipregisterdestroy_(int *__ierr ){
*__ierr = IPRegisterDestroy();
}
#if defined(__cplusplus)
}
#endif
