#include "petscsys.h"
#include "petscfix.h"
#include "private/fortranimpl.h"
/* ipform.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "slepcip.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ipsetmatrix_ IPSETMATRIX
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define ipsetmatrix_ ipsetmatrix
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ipapplymatrix_ IPAPPLYMATRIX
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define ipapplymatrix_ ipapplymatrix
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  ipsetmatrix_(IP *ip,Mat mat, int *__ierr ){
*__ierr = IPSetMatrix(*ip,
	(Mat)PetscToPointer((mat) ));
}
void PETSC_STDCALL  ipapplymatrix_(IP *ip,Vec x,Vec y, int *__ierr ){
*__ierr = IPApplyMatrix(*ip,
	(Vec)PetscToPointer((x) ),
	(Vec)PetscToPointer((y) ));
}
#if defined(__cplusplus)
}
#endif
